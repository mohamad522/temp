#include <Arduino.h>
#include <MKRWAN.h>

#define SECRET_APP_EUI "0123456789ABCDEF"
#define SECRET_APP_KEY "0123456789ABCDEF0123456789ABCDEF"

LoRaModem modem;

void setup() {

  Serial.begin(9600);
  delay(3000);
  bool lora_on = modem.begin(US915);
      if (lora_on)
          Serial.println("Démarrage du module LoRaWAN ... OK");
      else
          Serial.println("Démarrage du module LoRaWAN ...Echec");

  Serial.println(modem.version());
  delay(3000);
  Serial.print("Mon device EUI est: ");
  Serial.println(modem.deviceEUI());
  Serial.flush();

  /*
  
  bool connected_to_lorawan = modem.joinOTAA(SECRET_APP_EUI, SECRET_APP_KEY) ;
  
  if (connected_to_lorawan)
        Serial.println(F("Connexion au réseau LoRaWAN ... Ok"));
      else 
      Serial.println(F("Connexion au réseau LoRaWAN ...Echec")); 
  
  Serial.println(F("Mon DevAddr est :"));
  Serial.println (modem.getDevAddr());
  
  */
}

void loop() {

  Serial.print("Mon device EUI est: ");
  Serial.println(modem.deviceEUI());

  /*
  modem.beginPacket();
  modem.print("Bienvenue au cours de securite IoT");
  int  err = modem.endPacket(true);
  if (err > 0) {
    Serial.println("Message envoyé correctement");
  } else {
    Serial.println("Erreur d'envoi :(");
  }
  */
  
  delay(30000);
}
