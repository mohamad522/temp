#include <SPI.h>
#include <LoRa.h>

int compteur = 1;
byte message_a_envoyer [50]= "Bienvenue au cours securite IoT " ;
int nb_octets_a_envoyer = 32 ;
unsigned long Temps_debut_tx ;
float Temps_total_tx ;


void setup() {
  Serial.begin(9600); 
  delay(5000);

  Serial.println("Je suis l'émetteur");

  if (!LoRa.begin(868000000)) {
    Serial.println("Problème au démarrage du module LoRa!");
  }

   // Positionner les différents paramètres (puissance d'émission, SpreadingFactor, Bandwidth, CodingRate, etc.)
}

void loop() {

  Serial.print("Transmission du paquet: " + String(compteur));
 
  LoRa.beginPacket();

  LoRa.write(message_a_envoyer, nb_octets_a_envoyer);
    
  bool succes = LoRa.endPacket();

  if (succes)
  {    
    Serial.println("... Succes ...");   
  }
  else
  {
    Serial.println("... Echec ... ");   
  }

  compteur++;
  delay(10000);
}
